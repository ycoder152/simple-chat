﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace Chat
{
    public partial class frmClient : Form
    {


        private static ManualResetEvent DisconnectDone = new ManualResetEvent(false);
        private static ManualResetEvent SentDone = new ManualResetEvent(false);

        //private delegate void DisplayMSGD(string msg);

        byte[] ary = new byte[1024];

      
        Socket client = null;


        public frmClient()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            IPAddress ip;
            if (IPAddress.TryParse(textBox3.Text, out ip))
            {
                Connect(ip, (int)numericUpDown1.Value);
            }
            else
            {
                toolStripStatusLabel2.Text = "Invalid remote address :(";
            }
        }

        private void DisplayMSG(string msg)
        {
            //if (textBox1.InvokeRequired)
            //{
            //    DisplayMSGD dm = new DisplayMSGD(DisplayMSG);
            //    dm.Invoke(msg);
            //}

            textBox2.Text += "[" + DateTime.Now.ToString() + "]\r\n";
            textBox2.Text += "Server : " + msg + "\r\n";
            textBox2.SelectionStart = textBox2.TextLength;
            textBox2.ScrollToCaret();
        }

        private void frmClient_Load(object sender, EventArgs e)
        {
            Disconnected();
        }

        private bool SendData(string msg)
        {
            try
            {
                SentDone.Reset();
                byte[] byteData = Encoding.ASCII.GetBytes(msg);
                client.BeginSend(byteData, 0, byteData.Length, SocketFlags.None, SendDataCallBack, client);
                SentDone.WaitOne();
                return true;
            }

            catch
            {
                Disconnected();
                return false;
            }


        }

        private bool Connect(IPAddress ip, int port)
        {
           

            try
            {


                Disconnected();

                button1.Enabled = true;
                button2.Enabled = false;
                client = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                client.BeginConnect(ip, port,new AsyncCallback(ConnectedCallBack),client);
            
               // numericUpDown1.Enabled = false;
                toolStripStatusLabel2.Text = " Connecting ... ";
                return true;
            }

            catch
            {
                Disconnected();
                return false;
            }



        }

        private void ConnectedCallBack(IAsyncResult ar)
        {
            try
            {
                //client = ar.AsyncState as Socket;
                client.EndConnect(ar);
                client.BeginReceive(ary, 0, ary.Length, SocketFlags.None, new AsyncCallback(ReciveCallBack), client);
                Conneced();
            }
            catch
            {
                Disconnected();
            }

        }

       
        private void SendDataCallBack(IAsyncResult ar)
        {
            try
            {
            //    client = ar.AsyncState as Socket;
                client.EndSend(ar);
                SentDone.Set();
            }

            catch
            {
                Disconnected();
            }

        }

        private void ReciveCallBack(IAsyncResult ar)
        {

            try
            {

                client = ar.AsyncState as Socket;

                int buffer_size = client.EndReceive(ar);

                if (buffer_size > 0)
                {
                    byte[] msg = new byte[buffer_size];
                    Array.Copy(ary, msg, buffer_size);
                    DisplayMSG(ASCIIEncoding.UTF8.GetString(msg));

                    client.BeginReceive(ary, 0, ary.Length, SocketFlags.None, ReciveCallBack, client);
                }
                else
                {
                    throw new Exception("disconnected");
                }
            }

            catch
            {
                Disconnected();
            }

        }

        private void DisConnectBallBack(IAsyncResult ar)
        {
            try
            {
              //  client = (Socket)ar.AsyncState;
                client.EndDisconnect(ar);
                DisconnectDone.Set();
            }
            catch
            {

            }

        }
        private void Disconnected()
        {
            if (client != null)
            {
                if (client.Connected)
                {
                    DisconnectDone.Reset();
                    client.BeginDisconnect(false, new AsyncCallback(DisConnectBallBack), client);
                    DisconnectDone.WaitOne();

                    client.Close();
                }

                client.Dispose();
                client = null;
            }

            AC();

        }

       
        private void button1_Click(object sender, EventArgs e)
        {
            Disconnected();
        }

        private void AC()
        {
            button1.Enabled = false;
            button2.Enabled = true;
            button3.Enabled = false;

            textBox1.Enabled = false;
            textBox2.Enabled = false;
            textBox3.Enabled = true;

            button3.Enabled = false;

            numericUpDown1.Enabled = true;
            toolStripStatusLabel2.Text = "Disconnected";

        }

        private void Conneced()
        {
            button1.Enabled = true;
            button2.Enabled = false;
            button3.Enabled = true;

            textBox1.Enabled = true;
            textBox2.Enabled = true;
            textBox3.Enabled = false;

            numericUpDown1.Enabled = false;

            toolStripStatusLabel2.Text = "Connected :)";

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            
            Disconnected();
            

        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox1.Text))
            {
                return;
            }

            if (SendData(textBox1.Text))
            {
                
                DisplayMSG(textBox1.Text);
                textBox1.Clear();
            }
        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                button3_Click(sender, new EventArgs());
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void frmClient_FormClosing(object sender, FormClosingEventArgs e)
        {
            Disconnected();
        }

       
    }
}
